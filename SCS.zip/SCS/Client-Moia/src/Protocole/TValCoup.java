package Protocole;

/* Validite du coup */
public enum TValCoup{
    VALID, TIMEOUT, TRICHE
}