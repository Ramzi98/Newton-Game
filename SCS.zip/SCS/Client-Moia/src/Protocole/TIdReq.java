package Protocole;

/* Identificateurs des requetes */
public enum TIdReq {
    PARTIE, COUP
}
