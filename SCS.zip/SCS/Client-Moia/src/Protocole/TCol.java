package Protocole;

public enum TCol {
    UN, DEUX, TROIS, QUATRE, CINQ
}
