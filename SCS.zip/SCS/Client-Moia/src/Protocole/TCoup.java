package Protocole;

/* Coups possibles */
public enum TCoup {
    POSE, DEPL
}
