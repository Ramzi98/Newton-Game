package Protocole;

/*
 * Definition d'une position de case
 */
public enum TLg {
    A, B, C, D, E, F, G, H
}
