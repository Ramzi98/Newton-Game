package Protocole;

/*
 * Structures demande de partie
 */
public enum TCoul{
    BLEU, ROUGE
}
